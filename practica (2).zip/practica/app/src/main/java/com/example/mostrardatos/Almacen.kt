package com.example.mostrardatos

class Almacen {
}