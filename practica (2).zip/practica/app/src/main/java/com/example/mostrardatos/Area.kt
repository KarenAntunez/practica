package com.example.mostrardatos

class Area(NomArea:String) {
    var NomArea:String=NomArea

    fun setNombreAre(Nom:String){
        NomArea=Nom
    }
    fun getNombreArea():String{
        return NomArea

    }

}


