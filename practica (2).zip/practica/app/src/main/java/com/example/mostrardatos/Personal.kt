package com.example.mostrardatos

class Personal(idPersonal: String, nombrep: String) {
    private var idPersonal = idPersonal
    private var nombrep= nombrep

    fun setNombre(nom: String){
        nombrep = nom
    }

    fun getNombre(): String{
        return nombrep
    }
    fun setId(idP: String){
        idPersonal = idP
    }

    fun getId(): String{
        return idPersonal
    }
}