package com.example.mostrardatos

class Biblioteca {
    var Prestamos:String=""



}